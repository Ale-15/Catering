package com.example.demo.repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.Credenziali;

public interface credenzialiRepository extends CrudRepository<Credenziali,Long>{

	//public boolean existsByUsername(String username);

	public Optional<Credenziali> findByUsername(String username);

}
