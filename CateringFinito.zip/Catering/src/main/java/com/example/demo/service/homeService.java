package com.example.demo.service;

import org.springframework.stereotype.Service;

//import com.example.demo.repository.utenteRepository;

@Service
public class homeService {
	
//	@Autowired
//	private homeRepository hr;
}
